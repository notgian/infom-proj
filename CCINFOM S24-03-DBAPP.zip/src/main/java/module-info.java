module org.example.eqlab2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens org.example.eqlab2 to javafx.fxml;
    exports org.example.eqlab2;


}
