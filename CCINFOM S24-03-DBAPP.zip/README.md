# CCINFOM [S24 Group 3]: ITS Application

## Github Link
https://github.com/notgian/infom-proj

## How to Run

Ensure that you are in the root directory (same as this README file). Then, run with maven.

```
mvn javafx:run
```

### Requirements
* Must be using Java25
